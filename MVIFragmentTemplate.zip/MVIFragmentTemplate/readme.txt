****** README ******
1) Open terminal on mac or cmd as administrator on windows and <cd> (move) into this folder
2) Run <python mac-installer.py> on mac, on window run <python windows-installer.py> or <py windows-installer.py>
3) Restart Android Studio

****** USAGE *******
1) Select <app> folder -> Right Click -> New -> Other -> MVI Fragment
2) Replace <FeatureName> with actual feature name in first input field <Class Prefix or Feature Name>, e.g., Home
3) Replace <feature> with actual package name in seconf input field <Package or Directory Name>, e.g., home
4) <Traget Source Set> should be left unchanged to <main>