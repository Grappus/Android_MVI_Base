import os
import glob
from distutils.dir_util import copy_tree

# copy subdirectory example
fromDirectory = "MVIFragment"

path1 = os.environ['HOME']+"/Applications/*/Contents/plugins/android/lib/templates/other"
path2 = "/Applications/*/Contents/plugins/android/lib/templates/other"

paths = [path1, path2]
targets = list()

for x in paths:
	matched_paths = glob.glob(x)
	for y in matched_paths:
		target = y + "/" + fromDirectory
		copy_tree(fromDirectory, target)
		targets.append(target)

print ("\n***************** Installed **************\n")
print ("Installed in",len(targets),"locations.")
print ("\n***************** Locations **************\n")
print ("\n".join(targets)) 
print ("\n******************************************\n")